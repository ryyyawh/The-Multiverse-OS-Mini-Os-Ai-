pub fn mount_filesystem() {
    println!(">> End to End terpasang. Semua direktori aman.");
}