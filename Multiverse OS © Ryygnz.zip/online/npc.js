export function spawnNPC(id, x, y) {
  return {
    id,
    x,
    y,
    hp: 5,
    type: 'npc'
  };
}

export function moveRandom(npc, map) {
  const dirs = [
    { x: 0, y: -1 }, { x: 0, y: 1 },
    { x: -1, y: 0 }, { x: 1, y: 0 },
  ];
  const rand = dirs[Math.floor(Math.random() * dirs.length)];
  const nx = npc.x + rand.x;
  const ny = npc.y + rand.y;
  if (map[ny] && map[ny][nx] === '.') {
    npc.x = nx;
    npc.y = ny;
  }
}