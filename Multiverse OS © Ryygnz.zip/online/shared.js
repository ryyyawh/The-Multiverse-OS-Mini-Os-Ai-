export const defaultHP = 10;

export function isNear(p1, p2) {
  return Math.abs(p1.x - p2.x) + Math.abs(p1.y - p2.y) === 1;
}