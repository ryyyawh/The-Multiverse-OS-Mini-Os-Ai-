import { WebSocketServer } from 'ws';
import { map } from '../online/map.js';
import { defaultHP, isNear } from '../online/shared.js';
import { createInventory, pickItem } from '../online/inventory.js';
import { spawnNPC, moveRandom } from '../online/npc.js';

const wss = new WebSocketServer({ port: 8080 });
let players = {};
let playerCount = 0;
let npcs = [spawnNPC('npc1', 5, 5)];

wss.on('connection', ws => {
  const id = `player_${++playerCount}`;
  players[id] = {
    x: 2 + playerCount, y: 2,
    hp: defaultHP,
    inv: createInventory()
  };
  ws.send(JSON.stringify({ type: 'id', id }));

  ws.on('message', msg => {
    const data = JSON.parse(msg);
    const p = players[data.id];
    if (!p) return;

    if (data.type === 'move') {
      let nx = p.x;
      let ny = p.y;

      if (data.dir === 'up') ny--;
      if (data.dir === 'down') ny++;
      if (data.dir === 'left') nx--;
      if (data.dir === 'right') nx++;

      if (map[ny][nx] === '.') {
        p.x = nx;
        p.y = ny;
      }
    }

    if (data.type === 'attack') {
      for (const [pid, other] of Object.entries(players)) {
        if (pid !== data.id && isNear(p, other)) {
          other.hp -= 2;
          if (other.hp <= 0) {
            other.x = 1; other.y = 1;
            other.hp = defaultHP;
          }
        }
      }

      for (const npc of npcs) {
        if (isNear(p, npc)) {
          npc.hp -= 2;
          if (npc.hp <= 0) {
            pickItem(p.inv, 'coins');
            npc.hp = 5;
            npc.x = 1 + Math.floor(Math.random() * 5);
            npc.y = 1 + Math.floor(Math.random() * 5);
          }
        }
      }
    }

    if (data.type === 'chat') {
      broadcast({ type: 'chat', from: data.id, text: data.text });
    }

    broadcastState();
  });

  ws.on('close', () => {
    delete players[id];
    broadcastState();
  });

  broadcastState();
});

function broadcastState() {
  const state = {
    type: 'state',
    players,
    npcs
  };
  broadcast(state);
}

function broadcast(data) {
  const msg = JSON.stringify(data);
  for (const client of wss.clients) {
    if (client.readyState === 1) client.send(msg);
  }
}

// NPC auto move
setInterval(() => {
  for (const npc of npcs) moveRandom(npc, map);
  broadcastState();
}, 3000);