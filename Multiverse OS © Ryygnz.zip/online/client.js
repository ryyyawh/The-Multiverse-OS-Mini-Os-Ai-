import { WebSocket } from 'ws';
import readline from 'readline';
import { map } from '../online/map.js';

let id = null;
let players = {};
let npcs = [];

const ws = new WebSocket('ws://localhost:8080');

ws.on('message', msg => {
  const data = JSON.parse(msg);
  if (data.type === 'id') id = data.id;
  if (data.type === 'state') {
    players = data.players;
    npcs = data.npcs;
    renderMap();
  }
  if (data.type === 'chat') {
    console.log(`\n[${data.from}] ${data.text}`);
  }
});

function renderMap() {
  console.clear();
  for (let y = 0; y < map.length; y++) {
    let row = '';
    for (let x = 0; x < map[y].length; x++) {
      let char = map[y][x];

      for (const npc of npcs) {
        if (npc.x === x && npc.y === y) char = '!';
      }

      for (const [pid, p] of Object.entries(players)) {
        if (p.x === x && p.y === y) {
          char = pid === id ? '@' : '&';
        }
      }
      row += char;
    }
    console.log(row);
  }

  for (const [pid, p] of Object.entries(players)) {
    const me = pid === id ? '(YOU)' : '';
    console.log(`${pid}${me} - HP: ${p.hp} | Coins: ${p.inv.coins}`);
  }
}

readline.emitKeypressEvents(process.stdin);
process.stdin.setRawMode(true);
process.stdin.on('keypress', (_, key) => {
  if (!id) return;
  if (key.ctrl && key.name === 'c') process.exit();

  const moveMap = { w: 'up', s: 'down', a: 'left', d: 'right' };
  if (moveMap[key.name]) {
    ws.send(JSON.stringify({ type: 'move', id, dir: moveMap[key.name] }));
  }

  if (key.name === 'space') {
    ws.send(JSON.stringify({ type: 'attack', id }));
  }

  if (key.name === 'return') {
    process.stdout.write('\nChat: ');
    let input = '';
    process.stdin.once('data', chunk => {
      input += chunk.toString().trim();
      ws.send(JSON.stringify({ type: 'chat', id, text: input }));
    });
  }
});