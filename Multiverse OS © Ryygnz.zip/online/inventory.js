export function createInventory() {
  return {
    coins: 0,
    potion: 0,
  };
}

export function pickItem(inv, item) {
  if (inv[item] !== undefined) {
    inv[item]++;
  }
}