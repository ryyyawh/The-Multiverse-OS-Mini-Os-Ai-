import readline from 'readline';

// ===== MAP =====
let map = [
  '####################',
  '#.................#',
  '#.....####........#',
  '#................#',
  '#................#',
  '####################'
].map(row => row.split(''));

// ===== ENTITY POSITIONS =====
let player1 = { x: 2, y: 2 };
let player2 = { x: 5, y: 2 };

// ===== RENDER FUNCTION =====
function renderMap() {
  console.clear();
  for (let y = 0; y < map.length; y++) {
    let row = '';
    for (let x = 0; x < map[y].length; x++) {
      if (x === player1.x && y === player1.y) {
        row += '@'; // Player 1
      } else if (x === player2.x && y === player2.y) {
        row += '&'; // Player 2
      } else {
        row += map[y][x];
      }
    }
    console.log(row);
  }
}

// ===== MOVE FUNCTION =====
function move(player, dir) {
  let nx = player.x;
  let ny = player.y;

  if (dir === 'up') ny--;
  if (dir === 'down') ny++;
  if (dir === 'left') nx--;
  if (dir === 'right') nx++;

  const collision = (nx === player1.x && ny === player1.y) || (nx === player2.x && ny === player2.y);

  if (map[ny][nx] === '.' && !collision) {
    player.x = nx;
    player.y = ny;
  }

  renderMap();
}

// ===== INPUT HANDLER =====
readline.emitKeypressEvents(process.stdin);
process.stdin.setRawMode(true);
process.stdin.on('keypress', (_, key) => {
  if (key.ctrl && key.name === 'c') process.exit();

  // Player 1: WASD
  if (key.name === 'w') move(player1, 'up');
  if (key.name === 's') move(player1, 'down');
  if (key.name === 'a') move(player1, 'left');
  if (key.name === 'd') move(player1, 'right');

  // Player 2: IJKL
  if (key.name === 'i') move(player2, 'up');
  if (key.name === 'k') move(player2, 'down');
  if (key.name === 'j') move(player2, 'left');
  if (key.name === 'l') move(player2, 'right');
});

renderMap();