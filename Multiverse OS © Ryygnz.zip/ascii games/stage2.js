import readline from 'readline';

// ===== MAP =====
let map = [
  '####################',
  '#.................#',
  '#.....####........#',
  '#................#',
  '#................#',
  '####################'
].map(row => row.split(''));

// ===== ENTITY POSITIONS =====
let player = { x: 2, y: 2 };
let enemy = { x: 10, y: 3 };

// ===== RENDER FUNCTION =====
function renderMap() {
  console.clear();
  for (let y = 0; y < map.length; y++) {
    let row = '';
    for (let x = 0; x < map[y].length; x++) {
      if (x === player.x && y === player.y) {
        row += '@';
      } else if (x === enemy.x && y === enemy.y) {
        row += 'E';
      } else {
        row += map[y][x];
      }
    }
    console.log(row);
  }
}

// ===== MOVE PLAYER =====
function movePlayer(dir) {
  let nx = player.x;
  let ny = player.y;

  if (dir === 'up') ny--;
  if (dir === 'down') ny++;
  if (dir === 'left') nx--;
  if (dir === 'right') nx++;

  if (map[ny][nx] === '.' && (nx !== enemy.x || ny !== enemy.y)) {
    player.x = nx;
    player.y = ny;
  }

  renderMap();
}

// ===== MOVE ENEMY (RANDOM) =====
function moveEnemy() {
  const dirs = [
    { x: 0, y: -1 },
    { x: 0, y: 1 },
    { x: -1, y: 0 },
    { x: 1, y: 0 }
  ];
  const random = dirs[Math.floor(Math.random() * dirs.length)];
  const nx = enemy.x + random.x;
  const ny = enemy.y + random.y;

  if (map[ny][nx] === '.' && (nx !== player.x || ny !== player.y)) {
    enemy.x = nx;
    enemy.y = ny;
  }

  renderMap();
}

// ===== INPUT HANDLER =====
readline.emitKeypressEvents(process.stdin);
process.stdin.setRawMode(true);
process.stdin.on('keypress', (_, key) => {
  if (key.ctrl && key.name === 'c') process.exit();
  if (key.name === 'w') movePlayer('up');
  if (key.name === 's') movePlayer('down');
  if (key.name === 'a') movePlayer('left');
  if (key.name === 'd') movePlayer('right');
});

renderMap();
setInterval(moveEnemy, 500); // enemy jalan tiap 0.5 detik