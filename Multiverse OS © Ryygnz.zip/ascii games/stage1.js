import readline from 'readline';

// ===== MAP =====
let map = [
  '####################',
  '#.................#',
  '#.....####........#',
  '#................#',
  '#................#',
  '####################'
].map(row => row.split(''));

// ===== PLAYER POSITION =====
let player = { x: 2, y: 2 };

// ===== RENDER FUNCTION =====
function renderMap() {
  console.clear();
  for (let y = 0; y < map.length; y++) {
    let row = '';
    for (let x = 0; x < map[y].length; x++) {
      if (x === player.x && y === player.y) {
        row += '@';
      } else {
        row += map[y][x];
      }
    }
    console.log(row);
  }
}

// ===== MOVE FUNCTION =====
function move(dir) {
  let nx = player.x;
  let ny = player.y;

  if (dir === 'up') ny--;
  if (dir === 'down') ny++;
  if (dir === 'left') nx--;
  if (dir === 'right') nx++;

  if (map[ny][nx] === '.') {
    player.x = nx;
    player.y = ny;
  }

  renderMap();
}

// ===== INPUT HANDLER =====
readline.emitKeypressEvents(process.stdin);
process.stdin.setRawMode(true);
process.stdin.on('keypress', (_, key) => {
  if (key.ctrl && key.name === 'c') process.exit();
  if (key.name === 'w') move('up');
  if (key.name === 's') move('down');
  if (key.name === 'a') move('left');
  if (key.name === 'd') move('right');
});

renderMap();