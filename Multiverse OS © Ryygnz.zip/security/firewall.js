import fs from 'fs'
export const blockSuspiciousFiles = () => {
  const suspicious = fs.readdirSync('.').filter(f => f.includes('.exe') || f.includes('.sh'))
  if (suspicious.length > 0) {
    console.warn(`[FIREWALL] BLOCKED: ${suspicious.join(', ')}`)
  }
}