import fs from 'fs'
import os from 'os'

const logSecurity = (msg) => {
  console.log(`[SECURITY] ${msg} | © Ragannesiaa`)
}

const hideUserIP = () => {
  const interfaces = os.networkInterfaces()
  for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name]) {
      if (!net.internal) {
        net.address = 'HIDDEN_BY_SYSTEM'
      }
    }
  }
  logSecurity('User IP hidden from terminal log')
}

const protectCoreFiles = () => {
  const criticalFolders = ['bootloader', 'fs', 'ai', 'karnel', 'userland']
  criticalFolders.forEach(folder => {
    if (!fs.existsSync(folder)) {
      logSecurity(`WARNING: Missing critical folder: ${folder}`)
    }
  })
}

const injectTag = () => {
  console.log("System initialized and secured | © Ragannesiaa")
}

const runSecurity = () => {
  hideUserIP()
  protectCoreFiles()
  injectTag()
}

export default runSecurity