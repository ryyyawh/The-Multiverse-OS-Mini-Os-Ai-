import chokidar from 'chokidar'
export const startMonitoring = () => {
  const watcher = chokidar.watch(['./karnel', './ai'], { persistent: true })
  watcher.on('change', path => {
    console.log(`[MONITOR] File changed: ${path} | © Ragannesiaa`)
  })
}