// userland/shell.js
import readline from 'readline';
import { exec } from 'child_process';

export function startShell() {
  console.clear();
  console.log("Welcome to Xylays Shell Terminal");
  console.log("Type 'help' for available commands.\n");

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: 'XylaysOS > '
  });

  rl.prompt();

  rl.on('line', (line) => {
    const cmd = line.trim();

    if (cmd === 'exit') {
      console.log('Exiting shell...');
      rl.close();
    } else if (cmd === 'help') {
      console.log(`Available Commands:
- help         : Show this help
- exit         : Exit the shell
- system       : Show basic system info
- run <code>   : Run a command line code
`);
    } else if (cmd.startsWith('run ')) {
      const command = cmd.slice(4);
      exec(command, (err, stdout, stderr) => {
        if (err) {
          console.error(`Error: ${stderr}`);
        } else {
          console.log(stdout);
        }
        rl.prompt();
      });
      return;
    } else if (cmd === 'system') {
      console.log(`XylaysOS Runtime
- Userland Shell
- Language Interpreter
- AI Integrated
- Secure Kernel Booted
`);
    } else {
      console.log(`Unknown command: ${cmd}`);
    }

    rl.prompt();
  });

  rl.on('close', () => {
    process.exit(0);
  });
}