#include <iostream>
using namespace std;

int main() {
    string cmd;
    cout << "Multiverse Os Shell Ready > ";
    while (getline(cin, cmd)) {
        cout << "Kamu ngetik: " << cmd << endl;
    }
    return 0;
}