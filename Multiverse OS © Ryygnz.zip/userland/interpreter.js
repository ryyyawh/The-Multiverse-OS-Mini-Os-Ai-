import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import os from 'os';

export async function interpretCode(code, lang = 'js') {
  const tmpDir = os.tmpdir();
  const filename = `xylays_script_${Date.now()}`;

  let extension, command;

  switch (lang) {
    case 'js':
      extension = '.js';
      command = `node`;
      break;
    case 'py':
      extension = '.py';
      command = `python3`;
      break;
    case 'sh':
      extension = '.sh';
      command = `bash`;
      break;
    case 'cpp':
      extension = '.cpp';
      command = `g++`;
      break;
    case 'c':
      extension = '.c';
      command = `gcc`;
      break;
    default:
      return 'Unsupported language.';
  }

  const filePath = path.join(tmpDir, `${filename}${extension}`);
  fs.writeFileSync(filePath, code);

  return new Promise((resolve, reject) => {
    if (lang === 'cpp' || lang === 'c') {
      const outPath = path.join(tmpDir, `${filename}_out`);
      exec(`${command} ${filePath} -o ${outPath} && ${outPath}`, (err, stdout, stderr) => {
        if (err) return resolve(`Compile Error: ${stderr}`);
        resolve(stdout);
      });
    } else {
      exec(`${command} ${filePath}`, (err, stdout, stderr) => {
        if (err) return resolve(`Runtime Error: ${stderr}`);
        resolve(stdout);
      });
    }
  });
}