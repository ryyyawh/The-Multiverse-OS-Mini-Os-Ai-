import { interpretCode } from './interpreter.js'
import { startAIOnline } from '../ai/online.js'
import { startAIOffline } from '../ai/offline.js'
import { exec } from 'child_process'

export async function handleProgram(input, type = 'cli', lang = 'js') {
  input = input.trim()

  // Command mapping
  if (type === 'ai-online') {
    const result = await startAIOnline(input)
    return result + '\n\n© Ragannesiaa!!'
  }

  if (type === 'ai-offline') {
    const result = await startAIOffline(input)
    return result + '\n\n© Ragannesiaa!!'
  }

  if (type === 'interpreter') {
    const result = await interpretCode(input, lang)
    return result
  }

  if (type === 'shell') {
    return new Promise((resolve) => {
      exec(input, (err, stdout, stderr) => {
        if (err) return resolve(`Shell Error:\n${stderr}`)
        resolve(stdout)
      })
    })
  }

  return 'Unknown program type.'
}