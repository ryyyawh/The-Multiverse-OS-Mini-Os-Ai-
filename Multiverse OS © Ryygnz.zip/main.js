// main.js
// © Xylays!! | Multiverse OS V2 - Final Integration
import { spawn } from 'child_process';
import readline from 'readline';

console.clear();
console.log(`
  ╔═════  [ MULTI VERSE OS2  ]  ════╗
  ║   POiNN ASCII OS [ConsoleOS]         ║
  ╠══════════════════════════╣
  ║  1. Jalankan Game PA Online          ║
  ║  2. Keluar dari OS                      ║
  ╚══════════════════════════╝
© — Xylays ここだよ！
`);

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('\nPilih opsi (1/2): ', jawaban => {
  rl.close(); // tutup input
  if (jawaban === '1') {
    console.log('\n[INFO] Menjalankan Server...');
    const server = spawn('node', ['online/server.js'], { stdio: 'inherit' });

    setTimeout(() => {
      console.log('[INFO] Menjalankan Game...');
      spawn('node', ['online/client.js'], { stdio: 'inherit' });
    }, 1000);
  } else {
    console.log('\n[EXIT] Sampai jumpa di dunia ASCII jangan ragu buat balik lagi!');
    process.exit();
  }
});

//==============================================\\

import { launchOfflineAI } from './ai/ai_offline.js';
import karnelBoot from './karnel/karnel.js';
import galaxfs from './fs/galaxfs.js';
import { firewallCheck } from './security/firewall.js';
import { identifyDevice } from './security/identify.js';
import { monitorSecurity } from './security/monitor.js';
import shell from './userland/shell.js';
import interpreter from './userland/interpreter.js';
import handler from './userland/program-handler.js';
import { runAIOnline } from './ai/ai_online.js';

// ========== SYSTEM BOOT SEQUENCE ========== //
console.log('\n[ Multiverse OS Booting... ]');
firewallCheck();         // Security Layer 1
identifyDevice();        // Device Identification
monitorSecurity();       // Real-time Monitoring
karnelBoot();            // Boot karnel
galaxfs();               // File system initialized
launchOfflineAI();       // AI Offline System Non Active
shell();                 // Shell UI
interpreter();           // Interpreter Execution
handler();               // Application Handler
runAIOnline();          // AI Online System Active

// UI Desktop Load Info
console.log('\n[ UI System: ./userland/desktop-ui/index.html + style.css is active ]');

// SYSTEM ENDPOINT
console.log('\nSystem Ready | Multiverse OS V2');
console.log('© Ragannesiaa - Xylays!!');