// main.js
// © Xylays!! | Multiverse OS V2 - Final Integration

import { launchOfflineAI } from './ai/ai_offline.js';
import karnelBoot from './karnel/karnel.rs';
import galaxfs from './fs/galaxfs.rs';
import { firewallCheck } from './security/firewall.js';
import { identifyDevice } from './security/identify.cpp';
import { monitorSecurity } from './security/monitor.js';
import shell from './userland/shell.js';
import interpreter from './userland/interpreter.js';
import handler from './userland/program-handler.js';
import { runAIOnline } from './ai/ai_online.js';

// ========== SYSTEM BOOT SEQUENCE ========== //
console.log('\n[ Multiverse OS Booting... ]');
firewallCheck();         // Security Layer 1
identifyDevice();        // Device Identification
monitorSecurity();       // Real-time Monitoring
karnelBoot();            // Boot karnel
galaxfs();               // File system initialized
launchOfflineAI();       // AI Offline System Non Active
shell();                 // Shell UI
interpreter();           // Interpreter Execution
handler();               // Application Handler
runAIOnline();          // AI Online System Active

// UI Desktop Load Info
console.log('\n[ UI System: ./userland/desktop-ui/index.html + style.css is active ]');

// SYSTEM ENDPOINT
console.log('\nSystem Ready | Multiverse OS V2');
console.log('© Ragannesiaa - Xylays!!');