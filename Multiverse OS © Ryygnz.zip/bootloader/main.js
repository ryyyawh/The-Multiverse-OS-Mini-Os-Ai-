#include <stdio.h>

void boot_sequence() {
    printf(">> Bootloader aktif:Os Memulai sistem...\n");
}