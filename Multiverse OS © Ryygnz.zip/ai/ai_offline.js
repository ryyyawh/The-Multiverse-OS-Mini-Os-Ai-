export function aiOffline(input) {
  const res = `Simulasi AI offline menanggapi: "${input}"`
  return res
}