import fetch from 'node-fetch';

const API_KEY = 'AIzaSyC0kC64AhWZZT08lHAjAjvNCcdtuarsG_U';
const GEMINI_API = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${API_KEY}`;

export async function runAIOnline(prompt) {
  try {
    const body = {
      contents: [{ parts: [{ text: prompt }] }]
    };

    const response = await fetch(GEMINI_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    const result = await response.json();

    const text = result.candidates?.[0]?.content?.parts?.[0]?.text || 'Maaf, tidak ada respons.';

    return `${text}\n\n© Xylays!!`;
  } catch (err) {
    console.error('Error in AI Online:', err);
    return `Terjadi kesalahan saat menghubungi AI.\n\n© Xylays!!`;
  }
}